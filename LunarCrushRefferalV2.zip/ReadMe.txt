Requirement
- Windows / Linux
- PHP 7.4 (https://www.apachefriends.org/xampp-files/7.4.25/xampp-windows-x64-7.4.25-0-VC15-installer.exe)
- PHP IMAP

******************************************** TUTORIAL *********************************************

### Active PHP IMAP : https://stackoverflow.com/questions/60014019/enable-imap-php-in-xampp-windows

### Setting GMail (ex: abcdefg@gmail.com)
1. Siapkan Email GMail sebagai induk.
2. Login ke akun tersebut
3. Aktifkan IMAP GMail : https://www.youtube.com/watch?v=J55XEuPdenU
4. Setelah itu, masuk ke : https://myaccount.google.com/u/0/security, dan pilih menu "Akses aplikasi yang kurang aman", dan aktifkan.

### Mendapatkan email dot trick.
1. Sebagai contoh email yang saya pakai adalah 'abcdefg@gmail.com' email ini sudah di aktifkan IMAP sebelumnya.
2. Ketik di terminal "php dot.php"
3. Masukkan 'abcdefg' (didapatkan dari abcdefg@gmail.com).
4. Dan tuliskan output file (tanpa file extensi .txt)

### Setting Configuration 'config.php' (penjelasan sudah ada di file tersebut).

### Jika sudah selesai semua, ketik "php lunr.php"

******************************************** END TUTORIAL *********************************************

### Error :
- Fatal error: Uncaught Error: Call to undefined function imap() : https://stackoverflow.com/questions/60014019/enable-imap-php-in-xampp-windows
- Fatal error: Uncaught Error: Call to undefined function imap_header() : Downgrade ke PHP 7.4
- Fatal error: Uncaught Error: Call to undefined function imap_search() : Downgrade ke PHP 7.4