<?php

################################################################
/**
 * Google Account
 * email dan password akun gmail yang kalian sudah open IMAP.
 */
$imapEmail = ''; // example : example@gmail.com
$imapPassword = ''; // example : pass123
################################################################

################################################################
/**
 * List Email
 * 
 * list email dot trick yang sudah dibuatkan dalam 1 file .txt
 * 
 * example:
 * email.txt
 */
$emailList = '';
################################################################

################################################################
/**
 * Refferal Code
 * 
 * 6 digit terakhir dari refferal link atau setelah simbol '/'
 * 
 * example :
 * refferal link : https://lnr.app/s/d4NC0k
 * jadi yang dipake adalah "d4NC0k"
 */
$refferal = '';
################################################################